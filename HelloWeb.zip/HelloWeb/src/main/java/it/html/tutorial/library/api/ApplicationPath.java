package it.html.tutorial.library.api;

public @interface ApplicationPath {

	String value();

}
