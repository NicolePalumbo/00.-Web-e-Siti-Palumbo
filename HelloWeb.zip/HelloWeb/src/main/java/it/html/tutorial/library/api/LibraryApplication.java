package it.html.tutorial.library.api;

@ApplicationPath("api")
public class LibraryApplication extends ResourceConfig {
    public LibraryApplication() {
        packages("it.html.tutorial.library.api");
    }

	private void packages(String string) {
		// TODO Auto-generated method stub
		
	}
}
