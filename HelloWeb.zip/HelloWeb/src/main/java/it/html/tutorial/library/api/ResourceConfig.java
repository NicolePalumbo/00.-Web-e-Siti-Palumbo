package it.html.tutorial.library.api;

public class ResourceConfig {

}
